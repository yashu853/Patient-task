/**
 * 🏥 Tech.Care Clinical Dashboard Controller
 * Handles secure API connectivity, data parsing, and high-fidelity UI rendering.
 */

// 1. Configuration & Endpoint Constants
const API_URL = 'https://fedskillstest.coalitiontechnologies.workers.dev';
const AUTH_USER = 'coalition';
const AUTH_PASS = 'skills-test';

// Global state to store fetched data
let patientsData = [];
let selectedPatient = null;
let bloodPressureChartInstance = null;

// 2. Initializer on DOM Load
document.addEventListener('DOMContentLoaded', () => {
  fetchPatientData();
  
  // Setup Timeframe selector change listener
  const timeframeSelector = document.getElementById('timeframeSelector');
  if (timeframeSelector) {
    timeframeSelector.addEventListener('change', (e) => {
      if (selectedPatient) {
        renderBloodPressureChart(selectedPatient.diagnosis_history, e.target.value);
      }
    });
  }
});

// 3. Secure API Fetch
async function fetchPatientData() {
  try {
    // Generate Basic Auth token dynamically at runtime (no hardcoding of pre-encrypted string)
    const token = btoa(`${AUTH_USER}:${AUTH_PASS}`);
    
    const response = await fetch(API_URL, {
      method: 'GET',
      headers: {
        'Authorization': `Basic ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      throw new Error(`API Connection Failed: ${response.status} ${response.statusText}`);
    }
    
    patientsData = await response.json();
    console.log('Patients data successfully loaded:', patientsData.length, 'records');
    
    // Select Jessica Taylor by default
    selectedPatient = patientsData.find(p => p.name === 'Jessica Taylor');
    
    if (!selectedPatient && patientsData.length > 0) {
      selectedPatient = patientsData[0]; // Fallback to first patient
    }
    
    // Render the Dashboard UI
    renderPatientsSidebar();
    if (selectedPatient) {
      populatePatientDashboard(selectedPatient);
    }
    
  } catch (error) {
    console.error('Critical Dashboard Fetch Error:', error);
    showFetchErrorState(error.message);
  }
}

// 4. Populate All Dashboard Components
function populatePatientDashboard(patient) {
  // Update Patient Profile sidebar
  document.getElementById('patientName').textContent = patient.name;
  document.getElementById('patientAvatar').src = patient.profile_picture || 'https://fedskillstest.ct.digital/4.png';
  document.getElementById('patientDOB').textContent = formatDate(patient.date_of_birth);
  document.getElementById('patientGender').textContent = patient.gender;
  document.getElementById('patientPhone').textContent = patient.phone_number;
  document.getElementById('patientEmergency').textContent = patient.emergency_contact;
  document.getElementById('patientInsurance').textContent = patient.insurance_type;
  
  // Populate Vitals and Blood Pressure sidebar (from latest month)
  if (patient.diagnosis_history && patient.diagnosis_history.length > 0) {
    const latestDiagnosis = patient.diagnosis_history[0]; // First entry is the latest
    
    // BP systolic / diastolic
    document.getElementById('systolicValue').textContent = latestDiagnosis.blood_pressure.systolic.value;
    document.getElementById('systolicLevel').innerHTML = getLevelIndicatorHTML(latestDiagnosis.blood_pressure.systolic.levels);
    
    document.getElementById('diastolicValue').textContent = latestDiagnosis.blood_pressure.diastolic.value;
    document.getElementById('diastolicLevel').innerHTML = getLevelIndicatorHTML(latestDiagnosis.blood_pressure.diastolic.levels);
    
    // Three Vitals Cards
    document.getElementById('respValue').textContent = `${latestDiagnosis.respiratory_rate.value} bpm`;
    document.getElementById('respStatus').textContent = latestDiagnosis.respiratory_rate.levels;
    
    document.getElementById('tempValue').textContent = `${latestDiagnosis.temperature.value} °F`;
    document.getElementById('tempStatus').textContent = latestDiagnosis.temperature.levels;
    
    document.getElementById('heartValue').textContent = `${latestDiagnosis.heart_rate.value} bpm`;
    document.getElementById('heartStatus').textContent = latestDiagnosis.heart_rate.levels;
    
    // Render Blood Pressure Graph (defaults to 6 months)
    renderBloodPressureChart(patient.diagnosis_history, '6');
  }
  
  // Populate Diagnostic List table
  populateDiagnosticTable(patient.diagnostic_list);
  
  // Populate Lab Results list
  populateLabResults(patient.lab_results);
}

// 5. Render Patient Directory Sidebar
function renderPatientsSidebar() {
  const container = document.getElementById('patientsListContainer');
  if (!container) return;
  
  container.innerHTML = '';
  
  patientsData.forEach(patient => {
    const card = document.createElement('div');
    card.className = `patient-card ${patient.name === selectedPatient.name ? 'active' : ''}`;
    
    card.innerHTML = `
      <div class="patient-info">
        <img src="${patient.profile_picture}" alt="${patient.name}">
        <div class="patient-details">
          <span class="patient-name">${patient.name}</span>
          <span class="patient-meta">${patient.gender}, ${patient.age}</span>
        </div>
      </div>
      <button class="patient-card__action">
        <svg width="18" height="4" viewBox="0 0 18 4" fill="currentColor">
          <path d="M2 4C3.1 4 4 3.1 4 2C4 0.9 3.1 0 2 0C0.9 0 0 0.9 0 2C0 3.1 0.9 4 2 4ZM9 4C10.1 4 11 3.1 11 2C11 0.9 10.1 0 9 0C7.9 0 7 0.9 7 2C7 3.1 7.9 4 9 4ZM16 4C17.1 4 18 3.1 18 2C18 0.9 17.1 0 16 0C14.9 0 14 0.9 14 2C14 3.1 14.9 4 16 4Z"/>
        </svg>
      </button>
    `;
    
    // Dynamic click selection behavior
    card.addEventListener('click', () => {
      // Deactivate current active card
      const activeCard = container.querySelector('.patient-card.active');
      if (activeCard) activeCard.classList.remove('active');
      
      card.classList.add('active');
      selectedPatient = patient;
      populatePatientDashboard(patient);
    });
    
    container.appendChild(card);
  });
}

// 6. Populate Diagnostic List Table
function populateDiagnosticTable(diagnosticList) {
  const tbody = document.getElementById('diagnosticTableBody');
  if (!tbody) return;
  
  tbody.innerHTML = '';
  
  if (!diagnosticList || diagnosticList.length === 0) {
    tbody.innerHTML = `<tr><td colspan="3" style="text-align: center; color: var(--color-secondary);">No diagnoses recorded for this patient.</td></tr>`;
    return;
  }
  
  diagnosticList.forEach(diag => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td style="font-weight: 700;">${diag.name}</td>
      <td style="color: var(--color-secondary);">${diag.description}</td>
      <td class="diagnostic-status">${diag.status}</td>
    `;
    tbody.appendChild(row);
  });
}

// 7. Populate Lab Results List
function populateLabResults(labResults) {
  const container = document.getElementById('labListContainer');
  if (!container) return;
  
  container.innerHTML = '';
  
  if (!labResults || labResults.length === 0) {
    container.innerHTML = `<div style="text-align: center; color: var(--color-secondary); padding: 20px;">No lab reports available.</div>`;
    return;
  }
  
  labResults.forEach(result => {
    const item = document.createElement('div');
    item.className = 'lab-item';
    item.innerHTML = `
      <span class="lab-item-name">${result}</span>
      <button class="lab-download-btn" title="Download Report">
        <!-- Download SVG -->
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M19 9H15V3H9V9H5L12 16L19 9ZM12 14.17L14.34 11H13V5H11V11H9.66L12 14.17ZM2 18H22V20H2V18Z" fill="currentColor"/>
        </svg>
      </button>
    `;
    
    // Premium click animation / alert
    const downloadBtn = item.querySelector('.lab-download-btn');
    downloadBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      console.log(`Downloading report for: ${result}`);
      alert(`Preparing clinical download for: "${result}"`);
    });
    
    container.appendChild(item);
  });
}

// 8. Draw Blood Pressure Line Graph (Chart.js)
function renderBloodPressureChart(history, limit) {
  const canvas = document.getElementById('bloodPressureChart');
  if (!canvas) return;
  
  // Parse chronological records (API orders from newest to oldest; reverse for horizontal chart flow)
  let sortedHistory = [...history].reverse();
  
  // Apply limit constraints (e.g. last 6 months, last 12 months)
  if (limit !== 'all') {
    const count = parseInt(limit);
    // Slice from the end to get the latest records chronologically
    sortedHistory = sortedHistory.slice(-count);
  }
  
  // Abbreviate month names for clean display labels
  const monthAbbr = {
    "January": "Jan", "February": "Feb", "March": "Mar", "April": "Apr", "May": "May", "June": "Jun",
    "July": "Jul", "August": "Aug", "September": "Sep", "October": "Oct", "November": "Nov", "December": "Dec"
  };
  
  const labels = sortedHistory.map(entry => {
    const abrv = monthAbbr[entry.month] || entry.month.substring(0, 3);
    return `${abrv}, ${entry.year}`;
  });
  
  const systolicData = sortedHistory.map(entry => entry.blood_pressure.systolic.value);
  const diastolicData = sortedHistory.map(entry => entry.blood_pressure.diastolic.value);
  
  // Destroy previous instance to prevent layout overlapping bugs
  if (bloodPressureChartInstance) {
    bloodPressureChartInstance.destroy();
  }
  
  // Configure Chart.js lines
  const ctx = canvas.getContext('2d');
  bloodPressureChartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Systolic',
          data: systolicData,
          borderColor: '#C26EB4',
          backgroundColor: 'rgba(194, 110, 180, 0.1)',
          borderWidth: 3,
          pointBackgroundColor: '#E66E9A',
          pointBorderColor: '#FFFFFF',
          pointBorderWidth: 2,
          pointRadius: 6,
          pointHoverRadius: 8,
          tension: 0.4,
          fill: false
        },
        {
          label: 'Diastolic',
          data: diastolicData,
          borderColor: '#7E6CAB',
          backgroundColor: 'rgba(126, 108, 171, 0.1)',
          borderWidth: 3,
          pointBackgroundColor: '#8C6FE6',
          pointBorderColor: '#FFFFFF',
          pointBorderWidth: 2,
          pointRadius: 6,
          pointHoverRadius: 8,
          tension: 0.4,
          fill: false
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false // We use our own customized HTML sidebar legend
        },
        tooltip: {
          backgroundColor: '#07263E',
          titleFont: { family: 'Manrope', weight: 'bold' },
          bodyFont: { family: 'Manrope' },
          padding: 10,
          cornerRadius: 8,
          displayColors: true
        }
      },
      scales: {
        x: {
          grid: {
            display: false
          },
          ticks: {
            font: {
              family: 'Manrope',
              size: 11
            },
            color: '#707070'
          }
        },
        y: {
          min: 60,
          max: 180,
          grid: {
            color: '#CBC8D4',
            drawBorder: false
          },
          ticks: {
            stepSize: 20,
            font: {
              family: 'Manrope',
              size: 11
            },
            color: '#707070'
          }
        }
      }
    }
  });
}

// 9. Helper Utility: Level Indicators with arrows
function getLevelIndicatorHTML(levelString) {
  if (!levelString) return '<span>--</span>';
  
  let arrowSVG = '';
  const isHigher = levelString.toLowerCase().includes('higher');
  const isLower = levelString.toLowerCase().includes('lower');
  
  if (isHigher) {
    // Pink arrow up
    arrowSVG = `
      <svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 4px;">
        <path d="M5 0L10 5H0L5 0Z" fill="#C26EB4"/>
      </svg>
    `;
  } else if (isLower) {
    // Purple arrow down
    arrowSVG = `
      <svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 4px;">
        <path d="M5 6L0 1H10L5 6Z" fill="#8C6FE6"/>
      </svg>
    `;
  }
  
  return `
    ${arrowSVG}
    <span style="font-size: 14px; font-weight: 500;">${levelString}</span>
  `;
}

// 10. Helper Utility: Date Formatter (e.g. 1996-08-23 to August 23, 1996)
function formatDate(dateStr) {
  if (!dateStr) return '--';
  try {
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    
    const year = parts[0];
    const monthIndex = parseInt(parts[1]) - 1;
    const day = parseInt(parts[2]);
    
    const months = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    
    return `${months[monthIndex]} ${day}, ${year}`;
  } catch (e) {
    return dateStr;
  }
}

// 11. Error State UI Handler
function showFetchErrorState(message) {
  const container = document.getElementById('patientsListContainer');
  if (container) {
    container.innerHTML = `<div style="color: #ff3333; padding: 20px; font-size: 13px; text-align: center;">Unable to connect to clinical server.</div>`;
  }
  
  const diagBody = document.getElementById('diagnosticTableBody');
  if (diagBody) {
    diagBody.innerHTML = `<tr><td colspan="3" style="text-align: center; color: #ff3333; padding: 30px;">Error Loading Data: ${message}. Check internet connection or CORS.</td></tr>`;
  }
  
  const labContainer = document.getElementById('labListContainer');
  if (labContainer) {
    labContainer.innerHTML = `<div style="text-align: center; color: #ff3333; padding: 20px;">Could not load reports.</div>`;
  }
}